package be.helha.poo3.models;

public enum Rarity {
    common,uncommon,rare,epic,legendary;
}

