package be.helha.poo3.serverpoo.models;

public enum Rarity {
    common,uncommon,rare,epic,legendary;
}
