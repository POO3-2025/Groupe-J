package be.helha.poo3.serverpoo.models;

public enum Direction {
    UP, DOWN, LEFT, RIGHT;

}

