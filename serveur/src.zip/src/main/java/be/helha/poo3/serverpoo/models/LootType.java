package be.helha.poo3.serverpoo.models;

public enum LootType {
    junk,armor_piece,weapon,consumable
}
